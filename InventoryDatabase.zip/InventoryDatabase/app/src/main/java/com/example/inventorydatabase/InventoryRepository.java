package com.example.inventorydatabase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.inventorydatabase.Item;

import java.util.ArrayList;
import java.util.List;

public class InventoryRepository {
    private final DBHelper dbHelper;

    public InventoryRepository(Context ctx) {
        this.dbHelper = new DBHelper(ctx);
    }

    public List<Item> getAllItems() {
        List<Item> out = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.query(DBHelper.T_ITEMS,
                null, null, null, null, null, DBHelper.C_ITEM_NAME + " ASC");
        while (c.moveToNext()) {
            out.add(new Item(
                    c.getInt(c.getColumnIndexOrThrow(DBHelper.C_ITEM_ID)),
                    c.getString(c.getColumnIndexOrThrow(DBHelper.C_ITEM_NAME)),
                    c.getInt(c.getColumnIndexOrThrow(DBHelper.C_ITEM_QTY))
            ));
        }
        c.close();
        return out;
    }

    public long createItem(String name, int qty) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.C_ITEM_NAME, name);
        cv.put(DBHelper.C_ITEM_QTY, qty);
        return db.insert(DBHelper.T_ITEMS, null, cv);
    }

    public boolean updateQuantity(int id, int newQty) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.C_ITEM_QTY, newQty);
        int rows = db.update(DBHelper.T_ITEMS, cv, DBHelper.C_ITEM_ID + "=?",
                new String[]{String.valueOf(id)});
        return rows == 1;
    }

    public boolean deleteItem(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int rows = db.delete(DBHelper.T_ITEMS, DBHelper.C_ITEM_ID + "=?",
                new String[]{String.valueOf(id)});
        return rows == 1;
    }
}