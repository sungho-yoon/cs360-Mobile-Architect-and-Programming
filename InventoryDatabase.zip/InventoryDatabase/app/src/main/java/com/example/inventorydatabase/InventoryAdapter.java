package com.example.inventorydatabase;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.inventorydatabase.R;
import com.example.inventorydatabase.Item;

import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.VH> {

    public interface ItemCallbacks {
        void onIncrease(Item item);
        void onDecrease(Item item);
        void onDelete(Item item);
    }

    private final List<Item> data;
    private final ItemCallbacks callbacks;

    public InventoryAdapter(List<Item> data, ItemCallbacks callbacks) {
        this.data = data;
        this.callbacks = callbacks;
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Item item = data.get(position);
        h.tvName.setText(item.name);
        h.tvQty.setText(String.valueOf(item.quantity));

        h.btnPlus.setOnClickListener(v -> callbacks.onIncrease(item));
        h.btnMinus.setOnClickListener(v -> callbacks.onDecrease(item));
        h.btnDelete.setOnClickListener(v -> callbacks.onDelete(item));
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvName, tvQty;
        Button btnPlus, btnMinus, btnDelete;
        VH(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvQty = itemView.findViewById(R.id.tvQty);
            btnPlus = itemView.findViewById(R.id.btnPlus);
            btnMinus = itemView.findViewById(R.id.btnMinus);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}