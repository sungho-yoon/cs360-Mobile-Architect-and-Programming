package com.example.inventorydatabase;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.inventorydatabase.R;
import com.example.inventorydatabase.UserRepository;

public class LoginActivity extends AppCompatActivity {
    private EditText etUsername, etPassword;
    private UserRepository userRepo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        userRepo = new UserRepository(this);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnCreate = findViewById(R.id.btnCreate);

        btnLogin.setOnClickListener(v -> {
            String u = etUsername.getText().toString().trim();
            String p = etPassword.getText().toString().trim();

            if (TextUtils.isEmpty(u) || TextUtils.isEmpty(p)) {
                Toast.makeText(this, "Enter both username and password.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (userRepo.validateLogin(u, p)) {
                Intent i = new Intent(this, InventoryActivity.class);
                i.putExtra("username", u);   // pass username so InventoryActivity can use per-user prefs
                startActivity(i);
                finish();
            } else {
                Toast.makeText(this, "Invalid credentials.", Toast.LENGTH_SHORT).show();
            }
        });

        btnCreate.setOnClickListener(v -> {
            String u = etUsername.getText().toString().trim();
            String p = etPassword.getText().toString().trim();

            if (TextUtils.isEmpty(u) || TextUtils.isEmpty(p)) {
                Toast.makeText(this, "Enter a username and password to register.", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean created = userRepo.createUser(u, p);
            Toast.makeText(this,
                    created ? "Account created. You can log in." : "Username already exists.",
                    Toast.LENGTH_SHORT).show();
        });
    }
}