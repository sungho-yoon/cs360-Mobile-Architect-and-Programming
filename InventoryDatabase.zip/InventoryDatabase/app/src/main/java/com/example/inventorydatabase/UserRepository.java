package com.example.inventorydatabase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class UserRepository {
    private final DBHelper dbHelper;

    public UserRepository(Context ctx) {
        this.dbHelper = new DBHelper(ctx);
    }

    // Returns true if username/password match a row
    public boolean validateLogin(String username, String password) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.query(DBHelper.T_USERS,
                new String[]{DBHelper.C_USER_ID},
                DBHelper.C_USERNAME + "=? AND " + DBHelper.C_PASSWORD + "=?",
                new String[]{username, password}, null, null, null);
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    // Returns true if created, false if username already exists
    public boolean createUser(String username, String password) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.C_USERNAME, username);
        cv.put(DBHelper.C_PASSWORD, password);
        long id = -1;
        try {
            id = db.insertOrThrow(DBHelper.T_USERS, null, cv);
        } catch (Exception ignored) {}
        return id != -1;
    }
}