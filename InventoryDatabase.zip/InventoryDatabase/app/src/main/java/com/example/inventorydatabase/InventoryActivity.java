package com.example.inventorydatabase;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.inventorydatabase.R;
import com.example.inventorydatabase.InventoryRepository;
import com.example.inventorydatabase.Item;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity implements InventoryAdapter.ItemCallbacks {

    private static final String CHANNEL_ID = "low_stock_channel";
    private static final int NOTIF_BASE_ID = 1000;

    private static final String KEY_SMS_ENABLED = "sms_enabled";
    private static final String KEY_HAS_SIGNED_IN = "has_signed_in";

    private String currentUser = "default";
    private SharedPreferences prefs;

    private InventoryRepository repo;
    private InventoryAdapter adapter;
    private final List<Item> items = new ArrayList<>();

    private SwitchCompat switchSms;
    private boolean smsEnabled = false;
    private boolean canSendSms = false;

    // Request SEND_SMS at runtime
    private final ActivityResultLauncher<String> requestSmsPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                canSendSms = granted;
                if (granted) {
                    smsEnabled = true;
                    if (switchSms != null) switchSms.setChecked(true);
                    prefs.edit().putBoolean(KEY_SMS_ENABLED, true).apply();
                    Toast.makeText(this, "SMS enabled.", Toast.LENGTH_SHORT).show();
                } else {
                    smsEnabled = false;
                    if (switchSms != null) switchSms.setChecked(false);
                    prefs.edit().putBoolean(KEY_SMS_ENABLED, false).apply();
                    Toast.makeText(this, "SMS permission denied. Using in-app notifications only.", Toast.LENGTH_SHORT).show();
                }
            });

    // Request POST_NOTIFICATIONS on Android 13+
    private final ActivityResultLauncher<String> requestPostNotifications =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                // No-op: we already guard notify() and handle SecurityException.
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Identify current user (for per-user preferences)
        String extraUser = getIntent().getStringExtra("username");
        if (extraUser != null && !extraUser.trim().isEmpty()) {
            currentUser = extraUser.trim();
        }
        prefs = getSharedPreferences("prefs_" + currentUser, MODE_PRIVATE);

        createNotificationChannel();
        ensureNotificationPermissionIfNeeded();

        repo = new InventoryRepository(this);

        RecyclerView rv = findViewById(R.id.rvItems);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new InventoryAdapter(items, this);
        rv.setAdapter(adapter);

        switchSms = findViewById(R.id.switchSms);
        Button btnAdd = findViewById(R.id.btnAddItem);

        // Restore per-user toggle state
        smsEnabled = prefs.getBoolean(KEY_SMS_ENABLED, false);
        if (switchSms != null) switchSms.setChecked(smsEnabled);

        // Init current SMS permission flag
        canSendSms = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        if (switchSms != null) {
            switchSms.setOnCheckedChangeListener((button, isChecked) -> {
                if (isChecked) {
                    if (canSendSms) {
                        smsEnabled = true;
                        prefs.edit().putBoolean(KEY_SMS_ENABLED, true).apply();
                        Toast.makeText(this, "SMS enabled.", Toast.LENGTH_SHORT).show();
                    } else {
                        requestSmsPermission.launch(Manifest.permission.SEND_SMS);
                    }
                } else {
                    smsEnabled = false;
                    prefs.edit().putBoolean(KEY_SMS_ENABLED, false).apply();
                    Toast.makeText(this, "SMS disabled.", Toast.LENGTH_SHORT).show();
                    showSmsDisabledPopup(); // popup each time the user disables via switch
                }
            });
        }

        btnAdd.setOnClickListener(v -> showAddDialog());
        loadItems();

        // Show popup on sign-in if first time for this user OR SMS currently disabled
        maybeShowSmsPopupOnSignIn();
    }

    private void loadItems() {
        items.clear();
        items.addAll(repo.getAllItems());
        adapter.notifyDataSetChanged();
    }

    private void showAddDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_item, null);
        EditText etName = dialogView.findViewById(R.id.etName);
        EditText etQty  = dialogView.findViewById(R.id.etQty);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Add Item")
                .setView(dialogView)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(dlg -> {
            Button save = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            save.setOnClickListener(v -> {
                String name = etName.getText().toString().trim();
                String qtyStr = etQty.getText().toString().trim();

                if (name.isEmpty()) {
                    etName.setError("Name is required");
                    return; // keep dialog open
                }

                int qty = qtyStr.isEmpty() ? 0 : Integer.parseInt(qtyStr);
                repo.createItem(name, qty);
                loadItems();
                if (qty == 0) {
                    notifyLowStock(name); // in-app + (optional) SMS
                }
                dialog.dismiss();
            });
        });

        dialog.show();
    }

    /** InventoryAdapter callbacks **/
    @Override
    public void onIncrease(Item item) {
        int newQty = item.quantity + 1;
        if (repo.updateQuantity(item.id, newQty)) {
            item.quantity = newQty;
            adapter.notifyItemChanged(items.indexOf(item));
        }
    }

    @Override
    public void onDecrease(Item item) {
        int newQty = Math.max(0, item.quantity - 1);
        if (repo.updateQuantity(item.id, newQty)) {
            item.quantity = newQty;
            adapter.notifyItemChanged(items.indexOf(item));
            if (newQty == 0) {
                notifyLowStock(item.name);
            }
        }
    }

    @Override
    public void onDelete(Item item) {
        if (repo.deleteItem(item.id)) {
            int pos = items.indexOf(item);
            items.remove(pos);
            adapter.notifyItemRemoved(pos);
        }
    }

    /** Always show a local notification; optionally also send SMS if enabled+permitted. */
    private void notifyLowStock(String itemName) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Inventory alert")
                .setContentText("'" + itemName + "' has reached quantity 0.")
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        int id = NOTIF_BASE_ID + Math.abs(itemName.hashCode());
        safeNotify(id, builder);
        maybeSendSms(itemName);
    }

    private void maybeSendSms(String itemName) {
        if (!smsEnabled || !canSendSms) return;
        try {
            // For emulator testing, adjust to another running emulator number (e.g., 5556)
            String demoNumber = "5556";
            SmsManager.getDefault().sendTextMessage(
                    demoNumber,
                    null,
                    "Inventory alert: '" + itemName + "' has reached quantity 0.",
                    null, null
            );
            Toast.makeText(this, "SMS alert sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS (emulator limitations are common).", Toast.LENGTH_SHORT).show();
        }
    }

    /** Sign-in popup policy: show for brand-new users or when SMS is disabled. */
    private void maybeShowSmsPopupOnSignIn() {
        boolean hasSignedIn = prefs.getBoolean(KEY_HAS_SIGNED_IN, false);

        if (!hasSignedIn || !smsEnabled) {
            showSmsDisabledPopup();
        }

        // Mark that this user has signed in at least once
        prefs.edit().putBoolean(KEY_HAS_SIGNED_IN, true).apply();
    }

    private void showSmsDisabledPopup() {
        new AlertDialog.Builder(this)
                .setTitle("SMS alerts disabled")
                .setMessage("You’ll still receive in-app notifications when items hit zero. You can re-enable SMS any time from this screen.")
                .setPositiveButton("OK", null)
                .setNeutralButton("Re-enable SMS", (d, w) -> {
                    if (switchSms != null) switchSms.setChecked(true);
                })
                .show();

        // Optional: also post a status notification so there's a history trail
        postStatusNotification("SMS alerts disabled", "Only in-app notifications will be shown.");
    }

    private void postStatusNotification(String title, String text) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        safeNotify(NOTIF_BASE_ID + 1, builder);
    }

    /** Notification channel + permission helpers **/

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String name = "Low Stock";
            String desc = "Alerts when an item hits zero quantity";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(desc);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void ensureNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPostNotifications.launch(Manifest.permission.POST_NOTIFICATIONS);
            }
        }
    }

    private boolean canPostNotifications() {
        if (Build.VERSION.SDK_INT < 33) return true;
        return ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void safeNotify(int id, NotificationCompat.Builder builder) {
        if (!canPostNotifications()) {
            // Optionally hint to user via Toast/Snackbar
            // Toast.makeText(this, "Enable notifications to see system alerts.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            NotificationManagerCompat.from(this).notify(id, builder.build());
        } catch (SecurityException se) {
            Log.w("InventoryActivity", "POST_NOTIFICATIONS denied at runtime", se);
        }
    }
}
