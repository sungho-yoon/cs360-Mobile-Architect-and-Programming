package com.example.inventorydatabase;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "inventory.db";
    public static final int DB_VERSION = 1;

    // users table
    public static final String T_USERS = "users";
    public static final String C_USER_ID = "id";
    public static final String C_USERNAME = "username";
    public static final String C_PASSWORD = "password"; // For class use only; hash in real apps.

    // items table
    public static final String T_ITEMS = "items";
    public static final String C_ITEM_ID = "id";
    public static final String C_ITEM_NAME = "name";
    public static final String C_ITEM_QTY = "quantity";

    public DBHelper(Context ctx) {
        super(ctx, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsers = "CREATE TABLE " + T_USERS + " (" +
                C_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                C_USERNAME + " TEXT UNIQUE NOT NULL, " +
                C_PASSWORD + " TEXT NOT NULL" +
                ");";

        String createItems = "CREATE TABLE " + T_ITEMS + " (" +
                C_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                C_ITEM_NAME + " TEXT NOT NULL, " +
                C_ITEM_QTY + " INTEGER NOT NULL DEFAULT 0" +
                ");";

        db.execSQL(createUsers);
        db.execSQL(createItems);

        // Optional: seed a couple of demo rows
        db.execSQL("INSERT INTO " + T_ITEMS + " (" + C_ITEM_NAME + ", " + C_ITEM_QTY + ") VALUES ('Boxes', 5), ('Tape', 2);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + T_ITEMS);
        onCreate(db);
    }
}